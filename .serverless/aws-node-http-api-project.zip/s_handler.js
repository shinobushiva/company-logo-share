
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'shinobushiva',
  applicationName: 'myapp',
  appUid: 'xRqBZvMBFzCK2lHq9N',
  orgUid: '6K34RrBQpCVmWWQ3Th',
  deploymentUid: '1d395986-9e48-41f7-83cf-d0a5f8098553',
  serviceName: 'aws-node-http-api-project',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '6.2.2',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'aws-node-http-api-project-dev-handler', timeout: 6 };

try {
  const userHandler = require('./dist/handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}